// firebase-config.js

// Firebase App (the core Firebase SDK) is always required
// Make sure you've included this in your HTML before this file:
// <script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js"></script>
// <script src="https://www.gstatic.com/firebasejs/9.6.10/firebase-auth.js"></script>

const firebaseConfig = {
  apiKey: "AIzaSyBmwqM-Rl9GZ3xEy1NQR5x5aSZrVJl-9rA",
  authDomain: "spnshop-50797.firebaseapp.com",
  projectId: "spnshop-50797",
  storageBucket: "spnshop-50797.firebasestorage.app",
  messagingSenderId: "521506517253",
  appId: "1:521506517253:web:46fb315c47717e6f5a076c",
  measurementId: "G-X281P6KXT7"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);